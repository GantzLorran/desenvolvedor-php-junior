<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

    <title>Desafio Bizut</title>
  </head>
  <body class="bg-dark text-light">

    <div class="container">

      <div class="jumbotron bg-success">
        <h1>Bizut</h1>
        <h2>Crud com PHP orientado a objetos</h2>
      </div>
    
